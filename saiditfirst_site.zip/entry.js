
function goToHomepage() {
    const username = document.getElementById("username").value.trim();
    if (username.length > 0) {
        window.location.href = "homepage.html";
    } else {
        alert("Please enter a username.");
    }
}
