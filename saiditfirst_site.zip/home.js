
function checkSentence() {
    const sentence = document.getElementById("sentenceInput").value.trim();
    const feedback = document.getElementById("feedback");
    const wordCount = sentence.split(" ").filter(w => w).length;

    if (wordCount < 2 || wordCount > 4) {
        feedback.className = "feedback-warning";
        feedback.textContent = "Please enter between 2 to 4 words.";
    } else {
        const isUnique = Math.random() > 0.5;
        feedback.className = isUnique ? "feedback-correct" : "feedback-error";
        feedback.textContent = isUnique ? "Nice! This sentence has never been said before!" : "Oops! Someone has already said that.";
    }
}
